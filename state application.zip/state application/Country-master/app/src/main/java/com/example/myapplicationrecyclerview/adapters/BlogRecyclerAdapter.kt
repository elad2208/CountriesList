package com.example.myapplicationrecyclerview.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplicationrecyclerview.databinding.LayoutBlogListItemBinding
import com.example.myapplicationrecyclerview.models.Country
import kotlin.collections.ArrayList

class BlogRecyclerAdapter (
    private val listener: OnItemClickListener
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    private var items: List<Country> = ArrayList()

    interface OnItemClickListener {
        fun onItemClick(view: View , item: Country)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return BlogViewHolder(
            LayoutBlogListItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            ),
            listener
        )
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is BlogViewHolder -> {
                holder.bind(items[position])
            }
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

    fun submitList(blogList: List<Country>) {
        items = blogList
    }


    open class BlogViewHolder
    constructor(
        private val binding: LayoutBlogListItemBinding, listener: OnItemClickListener
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.run {
                this.listener = listener
            }
        }

        val blogTitle = binding.blogTitle
        val blogAuthor = binding.blogAuthor

        // taking each individual BlogPost object and bind it to the views in a layout
        fun bind(blogPost: Country) {
            binding.blogPost = blogPost

            blogTitle.text = blogPost.name
            blogAuthor.text = blogPost.englishName

        }
    }
}