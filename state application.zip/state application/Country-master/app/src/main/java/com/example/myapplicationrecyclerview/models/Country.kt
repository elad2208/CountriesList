package com.example.myapplicationrecyclerview.models

import java.util.ArrayList


public class Country{
    var id:Int=0
    lateinit var name:String
    lateinit var englishName:String
    lateinit var code:String
    lateinit var borders: ArrayList<String>

    constructor(id: Int,name:String,code:String,englishName:String,borders:ArrayList<String>) {
        this.id = id
        this.name = name
        this.code=code
        this.englishName = englishName
        this.borders = borders
    }

    constructor()
}