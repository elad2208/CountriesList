package com.example.myapplicationrecyclerview.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.doOnPreDraw
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.FragmentNavigatorExtras
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplicationrecyclerview.R
import com.example.myapplicationrecyclerview.adapters.BlogRecyclerAdapter
import com.example.myapplicationrecyclerview.databinding.FragmentHomeBinding
import com.example.myapplicationrecyclerview.models.Country
import com.google.android.material.transition.MaterialContainerTransform
import com.google.android.material.transition.MaterialElevationScale
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.IOException

var listCountry = ArrayList<Country>()

class HomeFragment : Fragment(), BlogRecyclerAdapter.OnItemClickListener {


    private lateinit var binding: FragmentHomeBinding
    private var blogAdapter = BlogRecyclerAdapter(this)
    val client = OkHttpClient()
    var num=0;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val postFragment = PostFragment()
        postFragment.sharedElementEnterTransition = MaterialContainerTransform()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        var num=0;
        val request = Request.Builder()
            .url("https://restcountries.com/v2/all")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
            }

            override fun onResponse(call: Call, response: Response) {
                var str_response = response.body()!!.string()
                //creating json object

                val jsonArray = JSONTokener(str_response).nextValue() as JSONArray
                var i:Int = 0
                var size:Int = jsonArray.length()
                listCountry= ArrayList();
                for (i in 0.. size-1) {
                    var json_objectdetail: JSONObject =jsonArray.getJSONObject(i)
                    var model:Country= Country();
                    model.name=json_objectdetail.getString("nativeName")
                    model.code=json_objectdetail.getString("alpha3Code")
                    val borders = ArrayList<String>()
                    if(json_objectdetail.has("borders") ){

                        var bordersString = json_objectdetail.getString("borders")
                        bordersString = bordersString.replace("[\"", "")
                        bordersString = bordersString.replace("\"]", "")

                        for (border in bordersString.trim { it <= ' ' }.split("\",\"".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()) {
                            if (border.isNotEmpty()) {
                                borders.add(border)
                            }
                        }

                    }
                    model.borders=borders
                    model.englishName=json_objectdetail.getString("name")
                    model.id= num
                    num=num+1
                    listCountry.add(model)
                }

                activity?.runOnUiThread (Runnable {
                    initRecycleView()
                    print(listCountry)
                    blogAdapter.submitList(listCountry)

                    postponeEnterTransition()
                    view.doOnPreDraw {
                        startPostponedEnterTransition()
                    }
                })
            }
        })
    }


    private fun initRecycleView() {
        binding.recycleView.apply {
            layoutManager = LinearLayoutManager(activity)
            adapter = blogAdapter
        }
    }

    override fun onItemClick(view: View, itemBlog: Country) {

        //to have the list of posts subtly scale out when exiting and back in when reentering:
        exitTransition = MaterialElevationScale(false).apply {
            duration = resources.getInteger(R.integer.reply_motion_duration_large).toLong()
        }
        reenterTransition = MaterialElevationScale(true).apply {
            duration = resources.getInteger(R.integer.reply_motion_duration_large).toLong()
        }
        /*
        create the mapping from your start view (posts list item) and end view (posts details screen):
        The FragmentNavigator.Extras class allows you to map shared elements from one destination to the next
         by their transition name
         */
        val postCardDetailTransitionName = getString(R.string.post_card_detail_transition_name)
        val extras = FragmentNavigatorExtras(view to postCardDetailTransitionName)
        // itemBlog.id - the value that we pass to post fragment
        val directions = HomeFragmentDirections.actionHomeFragmentToPostFragment(itemBlog.id.toLong())
        findNavController().navigate(directions, extras)
    }
}