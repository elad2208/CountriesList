package com.example.myapplicationrecyclerview.fragments

import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.myapplicationrecyclerview.R
import com.example.myapplicationrecyclerview.databinding.FragmentPostBinding
import com.google.android.material.transition.MaterialContainerTransform


class PostFragment : Fragment() {

    private val args: PostFragmentArgs by navArgs()
    /*
    lazy - memory is not allocated unless we use it.
    variable will not be initialized unless we use it in our code
     */
    private val postId: Long by lazy(LazyThreadSafetyMode.NONE) { args.blogPost }

    private lateinit var binding: FragmentPostBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        sharedElementEnterTransition = MaterialContainerTransform().apply {
            drawingViewId = R.id.nav_host_fragment
            duration = resources.getInteger((R.integer.reply_motion_duration_large)).toLong()
            scrimColor = Color.TRANSPARENT
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = FragmentPostBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.navigationBackIcon.setOnClickListener {
            findNavController().navigateUp()
        }
        initView()
    }



    private fun initView() {
       val blogPost = listCountry.get(postId.toInt())


       if (blogPost != null) {


            binding.run {
                blogTitle.text = blogPost.name

                val newlist = ArrayList<String>()

                print(blogPost)
                if(!blogPost.borders.isEmpty()) {
                    for (i in 0..blogPost.borders.size - 1) {
                        for (k in 0..listCountry.size - 1) {

                            if (blogPost.borders[i] == listCountry[k].code) {
                                var newBorder =
                                    listCountry[k].name + " - " + listCountry[k].englishName
                                newlist.add(newBorder)
                            }
                        }
                    }


                    val adapter = activity?.let {
                        ArrayAdapter<String>(
                            it,
                            android.R.layout.simple_spinner_item,
                            newlist
                        )
                    }

                    borderslist.setAdapter(adapter)
                }
            }

        }
    }
}