# CountriesList-Kotlin
Kotlin, MVVM, RXJAVA, Retrofit, Glide
